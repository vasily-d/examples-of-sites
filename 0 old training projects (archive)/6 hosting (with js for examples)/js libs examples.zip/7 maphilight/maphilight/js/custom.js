$(function() {

    $("#js-plan").maphilight({
        fill: true,
        fillColor: '62db22',
        fillOpacity: 0.8,
        stroke: false,
        strokeColor: 'ff0000',
        strokeOpacity: 1,
        strokeWidth: 1,
        fade: true,
        alwaysOn: false,
        neverOn: false,
        groupBy: false,
        wrapClass: false,
        shadow: true,
        shadowX: 0,
        shadowY: 0,
        shadowRadius: 5,
        shadowColor: '000000',
        shadowOpacity: 0.8,
        shadowPosition: 'outside',
        shadowFrom: false
    });

});
