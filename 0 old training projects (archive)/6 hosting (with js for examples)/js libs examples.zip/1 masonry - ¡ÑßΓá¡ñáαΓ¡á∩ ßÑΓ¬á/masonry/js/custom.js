$(function() {

    $('.news').masonry({
        itemSelector: '.news__item',
        columnWidth: 200,
        gutter: 20
    });

});
