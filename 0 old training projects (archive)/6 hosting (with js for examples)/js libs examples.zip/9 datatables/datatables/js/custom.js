$(function() {



    $('#js-car-table').DataTable({
        "language": {
            "url": "js/datatables_lang_ru.json"
        }
    });


});
